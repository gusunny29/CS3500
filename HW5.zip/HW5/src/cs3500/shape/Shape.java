package cs3500.shape;

/**
 * Represents an interface for all different types of Shapes. Includes methods that each Shape
 * class should be able to support.
 */
public interface Shape {

}
